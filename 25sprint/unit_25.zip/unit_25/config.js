const URL = "https://api.itgid.info";
const APIKEY = "CaDrbgqZi7XZiS3k";

// никаких других изменений, добавлений
// оптимизаций - в файл config не вносим!!!