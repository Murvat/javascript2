const URL = "https://api.itgid.info";
const APIKEY = "nfS1uwZfZvN0EWIg";

// никаких других изменений, добавлений
// оптимизаций - в файл config не вносим!!!